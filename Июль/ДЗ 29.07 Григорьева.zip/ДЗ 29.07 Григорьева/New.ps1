﻿Set-Location 'C:/123'
Write-Host "Переход в каталог 123"

New-Item -ItemType Directory -Path 'C:/123/456'
Write-Host "Создан каталог 456"

$file = @("abc.txt" , "xyz.txt")
foreach ($doc in $file) {
Set-Location 'C:/123/456'
$line = "Меня зовут $doc"
$line | Out-File -FilePath $doc -Encoding UTF8
}
Write-Host "Созданы и записаны файлы abc.txt и xyz.txt"
